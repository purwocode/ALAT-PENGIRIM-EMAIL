<?php
return [
    [
        'smtp_host' => 'smtp-relay.gmail.com',
        'smtp_port' => 587,
        'smtp_encryption' => 'tls',
        'smtp_username' => 'aowkaofinf@freesignalbinary.com',
        'smtp_password' => 'wrry hjdh mdcv dalo',
    ],
    [
        'smtp_host' => 'smtp-relay.gmail.com',
        'smtp_port' => 587,
        'smtp_encryption' => 'tls',
        'smtp_username' => 'zvkoalhqd9700nzvkoalhqd970@kateequipement.ma',
        'smtp_password' => 'zxcasdqwe321$',
    ],
    // Tambahkan konfigurasi SMTP lainnya jika diperlukan
];
